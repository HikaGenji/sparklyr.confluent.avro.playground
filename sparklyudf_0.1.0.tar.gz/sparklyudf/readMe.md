sparklyr extension package to support deserializing Confluent Schema Registry avro encoded messages.
